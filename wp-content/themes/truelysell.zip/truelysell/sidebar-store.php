<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WorkScout
 */
?>
<div class="col-lg-3 col-md-4 col-sidebar">
    <div class="sidebar right">
      <?php dynamic_sidebar( 'sidebar-store' ); ?>
    </div>
 </div>