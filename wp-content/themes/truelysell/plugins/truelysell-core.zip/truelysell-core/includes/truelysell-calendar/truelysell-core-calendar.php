<?php

require_once __DIR__ . DIRECTORY_SEPARATOR . 'truelysell-core-calendar-reader.php';
require_once __DIR__ . DIRECTORY_SEPARATOR . 'truelysell-core-calendar-event-reader.php';